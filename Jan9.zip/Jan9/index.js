function myfun()
{
    stuName = document.getElementById("name").value
    ul = document.getElementById("names")
    li = document.createElement("li")
    text = document.createTextNode(stuName)
    li.appendChild(text)
    ul.appendChild(li)


    h1_data = document.getElementById("heading_stu").innerHTML
    h1_data += stuName + ", " 
    document.getElementById("heading_stu").innerHTML = h1_data
}