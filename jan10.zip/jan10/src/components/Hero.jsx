import React from 'react'

const Hero = () => {
  return (
    <main className='hero container'>
        <div className='hero-content'>
            <h1>Your feet deserve the best</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque ex dolorem vitae eveniet sapiente nemo culpa sequi,<br /> sint beatae quos voluptas deserunt fuga, eum itaque voluptatem facere rem in illum.</p>
            <div className='hero-btn'>
                <button>Shop now</button>
                <button className='secondary-btn'>Category</button>
            </div>
            <div className='shopping'>
                <p>Also available on</p>
                <div className='brand-icons'>
                    <img  src='/images/amazon.png' alt='amazon-logo' />
                    <img  src='/images/flipkart.png' alt='flipkart-logo' />
                    
                </div>
            </div>
        </div>
        <div className='hero-image'>
            <img src='/images/hero-image.png' alt='hero-img' />
        </div>      
    </main>
  )
}

export default Hero
