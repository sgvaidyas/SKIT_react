const Home = ()=>{
    return (
        <>
         <div id="content">
            Home
        </div>
        </>
    )
}
export default Home;