const Footer  = ()=>{
    return (
        <>
        <div id="bottombanner">
            Footer
        </div>
        </>
    )
}
export default Footer ;