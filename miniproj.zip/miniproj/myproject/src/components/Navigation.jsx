const Navigation = ()=>{
    return (
        <>
        <div id="header">
            <div id="logo">
                <img src="/images/logo.jpg" alt = " logo" />
            </div>
            <div id="menu">
                <ul>
                    <li>AAA</li>
                    <li>AAA</li>
                    <li>AAA</li>
                    <li>AAA</li>
                    <li>AAA</li>
                </ul>
            </div>
        </div>
        </>
    )
}
export default Navigation;